package guisfc.com.app1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

public class Tela2Activity extends AppCompatActivity {

    private EditText etPlaca;
    private EditText etCor;
    private CheckBox cbNovo;
    private Button btnEnviar;
    private Spinner spMarca;

    private String marca[] = {"Chevrolet", "Fiat", "Ford", "Volkswagen"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        inicializarComponentes();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Tela2Activity.this,android.R.layout.simple_list_item_1,marca);
        spMarca.setAdapter(adapter);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Tela2Activity.this, Tela3Activity.class);
                intent.putExtra("et_placa",etPlaca.getText().toString());
                intent.putExtra("et_cor",etCor.getText().toString());
                intent.putExtra("cb_novo",cbNovo.isChecked());
                intent.putExtra("sp_marca",spMarca.getSelectedItem().toString());
                startActivity(intent);
            }
        });

    }

    private void inicializarComponentes() {
        etPlaca = (EditText) findViewById(R.id.et_placa);
        etCor = (EditText) findViewById(R.id.et_cor);
        cbNovo = (CheckBox) findViewById(R.id.cb_novo);
        btnEnviar = (Button) findViewById(R.id.btn_enviar);
        spMarca = (Spinner) findViewById(R.id.sp_marca);
    }
}
