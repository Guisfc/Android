package guisfc.com.app1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Tela3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);

        Toast.makeText(Tela3Activity.this, "Toast: ["+getIntent().getStringExtra("et_placa")+
                "], ["+getIntent().getStringExtra("et_cor")+
                "], ["+getIntent().getStringExtra("sp_marca")+
                "], ["+getIntent().getBooleanExtra("cb_novo",false)+
                "]",Toast.LENGTH_LONG).show();

    }
}
