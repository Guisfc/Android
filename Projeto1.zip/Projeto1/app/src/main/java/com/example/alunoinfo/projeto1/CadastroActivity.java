package com.example.alunoinfo.projeto1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    private TextView tvNome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        inicializaComponentes();

        tvNome.setText(getIntent().getStringExtra("nome"));

        Toast.makeText(CadastroActivity.this, getIntent().getStringExtra("nome"), Toast.LENGTH_LONG).show();
    }

    private void inicializaComponentes() {
        tvNome = (TextView) findViewById(R.id.tv_nome);
    }
}
