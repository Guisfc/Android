package com.example.alunoinfo.projeto1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button btnCadastrar;
    private EditText etNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializaComponentes();

        this.btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valorNome = etNome.getText().toString();


                Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
                intent.putExtra("nome", valorNome);
                startActivity(intent);

            }
        });
    }

    private void inicializaComponentes() {
        btnCadastrar = (Button) findViewById(R.id.btn_cadastrar);
        etNome = (EditText) findViewById(R.id.et_nome);
    }
}
