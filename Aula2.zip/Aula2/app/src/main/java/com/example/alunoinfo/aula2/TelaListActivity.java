package com.example.alunoinfo.aula2;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

/**
 * Created by alunoinfo on 14/12/17.
 */

public class TelaListActivity extends ListActivity {

    private String listaCarros[] = {"Stilo","Punto","Civic"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ArrayAdapter adapterCarros = new ArrayAdapter(TelaListActivity.this,android.R.layout.simple_list_item_1,listaCarros);

        super.setListAdapter(adapterCarros);

    }
}
