package com.example.alunoinfo.aula2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toast.makeText(Main2Activity.this,"Marca: " + getIntent().getStringExtra("actMarca") + "\nCidade: " + getIntent().getStringExtra("spCidade") + "\nNovo: " + getIntent().getBooleanExtra("cbNovo",false) + "\nPortas: " + getIntent().getStringExtra("rbSelected"),Toast.LENGTH_LONG).show();
    }
}
