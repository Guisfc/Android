package com.example.alunoinfo.aula2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView actMarca;
    private Spinner spCidade;
    private Button btOk;
    private CheckBox cbNovo;
    private RadioGroup rgPortas;
    private String listaMarcas[] = {"Chevrolet","Fiat","Hyundai","Renault","Volkswagen","BMW","Audi"};
    private String listaCidades[] = {"","Sapucaia do Sul","Esteio","São Leopoldo","Canoas","Porto Alegre","Novo Hamburgo"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializaComponentes();
        ArrayAdapter<String> adapterMarca = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,listaMarcas);
        actMarca.setAdapter(adapterMarca);
        ArrayAdapter<String> adapterCidade = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,listaCidades);
        spCidade.setAdapter(adapterCidade);

        btOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                intent.putExtra("actMarca",actMarca.getText().toString());
                intent.putExtra("spCidade",spCidade.getSelectedItem().toString());
                intent.putExtra("cbNovo",cbNovo.isChecked());

                RadioButton rbSelected = (RadioButton) findViewById(rgPortas.getCheckedRadioButtonId());
                intent.putExtra("rbSelected",rbSelected.getText().toString());

                Intent intentListActivity = new Intent(MainActivity.this,TelaListActivity.class);
                //startActivity(intentListActivity);  Abre outra lista
                startActivity(intent);
            }
        });

    }

    private void inicializaComponentes() {
        btOk = (Button) findViewById(R.id.bt_ok);
        actMarca = (AutoCompleteTextView) findViewById(R.id.act_marca);
        spCidade = (Spinner) findViewById(R.id.sp_cidade);
        btOk = (Button) findViewById(R.id.bt_ok);
        cbNovo = (CheckBox) findViewById(R.id.cb_novo);
        rgPortas = (RadioGroup) findViewById(R.id.rg_portas);

    }
}
