package guisfc.com.ex2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private EditText etNome;
    private RadioGroup rgSexo;
    private CheckBox cbMusica;
    private CheckBox cbFilme;
    private Button btCadastrar;
    private Button btEnviar;

    private ArrayList<Usuario> usuariosCadastrados = new ArrayList<Usuario>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializaComponentes();

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Usuario usuario = new Usuario();
                RadioButton rbSelecionado = findViewById(rgSexo.getCheckedRadioButtonId());

                usuario.setNome(etNome.getText().toString());
                usuario.setSexo(rbSelecionado.getText().toString());
                usuario.setMusica(cbMusica.isChecked());
                usuario.setFilme(cbFilme.isChecked());
                usuariosCadastrados.add(usuario);
                limparCampos();
            }
        });

        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentList = new Intent(MainActivity.this,TelaListActivity.class);
                intentList.putExtra("listaUsuarios",usuariosCadastrados);
                startActivity(intentList);
            }
        });

    }

    private void inicializaComponentes() {
        etNome = (EditText) findViewById(R.id.et_nome);
        rgSexo = (RadioGroup) findViewById(R.id.rg_sexo);
        cbMusica = (CheckBox) findViewById(R.id.cb_musica);
        cbFilme = (CheckBox) findViewById(R.id.cb_filme);
        btCadastrar = (Button) findViewById(R.id.bt_cadastrar);
        btEnviar = (Button) findViewById(R.id.bt_enviar);
    }

    private void limparCampos() {
        etNome.setText("");
        rgSexo.clearCheck();
        cbMusica.setChecked(false);
        cbFilme.setChecked(false);
    }
}
