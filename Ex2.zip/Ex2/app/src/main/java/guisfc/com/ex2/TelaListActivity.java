package guisfc.com.ex2;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaListActivity extends ListActivity {

    private ArrayList<Usuario> listaUsuarios;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listaUsuarios = (ArrayList<Usuario>) getIntent().getSerializableExtra("listaUsuarios");
        ArrayAdapter adapterUsuarios = new ArrayAdapter(TelaListActivity.this,android.R.layout.simple_list_item_1,listaUsuarios);
        setListAdapter(adapterUsuarios);


    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        int clienteSelecionado = position;

        Usuario usuario = listaUsuarios.get(clienteSelecionado);

        Intent intent = new Intent(TelaListActivity.this,Main3Activity.class);
        intent.putExtra("nome",usuario.getNome());
        intent.putExtra("sexo",usuario.getSexo());
        intent.putExtra("musica",usuario.isMusica());
        intent.putExtra("filme",usuario.isFilme());

        startActivity(intent);
    }
}
