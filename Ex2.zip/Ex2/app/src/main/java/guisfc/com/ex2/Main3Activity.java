package guisfc.com.ex2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Toast.makeText(Main3Activity.this,
                "Nome: " +getIntent().getStringExtra("nome")+ "\n"+
                "Sexo: " +getIntent().getStringExtra("sexo")+ "\n"+
                "Música: " +getIntent().getBooleanExtra("musica",false)+ "\n"+
                "Filme: " +getIntent().getBooleanExtra("filme",false),Toast.LENGTH_LONG).show();
    }
}
